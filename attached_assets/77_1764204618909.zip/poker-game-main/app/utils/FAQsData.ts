import { FAQ } from '../interfaces';

export const FAQs: FAQ[] = [
    {
        question:
            'Pariatur consequat ullamco ex et nulla reprehenderit esse in consequat sit Lorem?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
    {
        question: 'Non mollit occaecat tempor eu cupidatat laborum ut fugiat?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
    {
        question: 'Qui minim nostrud proident aliquip labore adipisicing?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
    {
        question:
            'Est minim excepteur aute occaecat nostrud veniam ex laborum enim cillum eiusmod sint?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
    {
        question: 'Qui minim nostrud proident aliquip labore adipisicing?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
    {
        question:
            'Voluptate dolor amet eu ad ad mollit aliquip laboris qui minim duis consequat?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
    {
        question: 'Qui minim nostrud proident aliquip labore adipisicing?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
    {
        question:
            'Laboris dolore eiusmod et laboris amet anim in labore qui nulla Lorem?',
        answer: 'Est est deserunt elit est ad esse laborum voluptate. Nisi eiusmod dolor dolore mollit anim amet consectetur. Aliqua magna nulla pariatur id ex veniam minim cillum ipsum duis exercitation in voluptate. Nulla commodo tempor ut dolor veniam reprehenderit aliqua. Non non ea elit labore cillum est velit nulla est consectetur officia. Sit nulla elit ut adipisicing dolore cillum laborum eu.',
    },
];
