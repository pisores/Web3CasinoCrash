export const HOTKEY_BACK = 'b';
export const HOTKEY_RAISE = 'r';
export const HOTKEY_CALL = 'c';
export const HOTKEY_CHECK = 'k';
export const HOTKEY_FOLD = 'f';
