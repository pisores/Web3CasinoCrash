module.exports = {
    payout: 1.98
}