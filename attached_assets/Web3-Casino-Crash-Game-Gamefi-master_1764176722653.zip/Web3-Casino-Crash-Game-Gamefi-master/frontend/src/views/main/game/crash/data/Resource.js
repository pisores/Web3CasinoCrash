export const Resource = [
    {'key': 'bg',           'src': '../../../assets/images/crash/background.png'},
    {'key': 'rocket',       'src': '../../../assets/images/crash/rocket.png'},
    {'key': 'history',      'src': '../../../assets/images/crash/history.png'},
    {'key': 'crash',        'src': '../../../assets/images/crash/crash.png'},
    {'key': 'explosion',    'src': '../../../assets/images/crash/explosion.json'},
    {'key': 'coin_bnb',     'src': '../../../assets/images/crash/coin_bnb.png'},
    {'key': 'coin_btc',     'src': '../../../assets/images/crash/coin_btc.png'},
    {'key': 'coin_eth',     'src': '../../../assets/images/crash/coin_eth.png'},
    {'key': 'coin_trx',     'src': '../../../assets/images/crash/coin_trx.png'},
    {'key': 'coin_usdt',     'src': '../../../assets/images/crash/coin_usdt.png'},
    {'key': 'coin_zelo',     'src': '../../../assets/images/crash/coin_zelo.png'},
];