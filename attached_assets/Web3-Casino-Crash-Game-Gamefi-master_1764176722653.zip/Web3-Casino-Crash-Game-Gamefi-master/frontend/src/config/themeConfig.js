const themeConfig = {
    basename: '/',
    defaultPath: '/home',
    fontFamily: `'Roboto', sans-serif`,
    borderRadius: 12
};

export default {
    themeConfig
};