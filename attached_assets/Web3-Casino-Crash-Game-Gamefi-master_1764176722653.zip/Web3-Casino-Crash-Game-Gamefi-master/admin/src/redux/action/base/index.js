// import { io } from 'socket.io-client';
// import Config from '../../../config/index';

const baseInit = async () => {
    // Config.Root.socket = io(Config.Root.socketServerUrl, { transports: ['websocket'] });
}

export default baseInit